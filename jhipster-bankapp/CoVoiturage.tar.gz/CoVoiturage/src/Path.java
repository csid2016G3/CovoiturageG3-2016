
public class Path {

	public Path() {
		super();
	}

}
