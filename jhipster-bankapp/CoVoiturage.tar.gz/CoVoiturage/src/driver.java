import java.util.ArrayList;

public class driver {

	private String DriverFirstName;
	private String DriverLastName;
	private String DriverPhone;
	private String DriverAddress;
	private String DriverMail;
	private int DriverAge;
	private int DriverExperience; //année d'experience
	private int DriverExp;
	
	private ArrayList<Car> DriverCars;
	//private ArrayList<>DriverDriveHistory; besoin de la classe ride
	private ArrayList<Path> DriverPathList;

	public driver() {
		// TODO Auto-generated constructor stub
	}

	public driver(String driverFirstName, String driverLastName, String driverPhone, String driverAddress,
			String driverMail, int driverAge, int driverExp, ArrayList<Car> driverCars,
			ArrayList<Path> driverPathList) {
		super();
		DriverFirstName = driverFirstName;
		DriverLastName = driverLastName;
		DriverPhone = driverPhone;
		DriverAddress = driverAddress;
		DriverMail = driverMail;
		DriverAge = driverAge;
		DriverExp = driverExp;
		DriverCars = driverCars;
		DriverPathList = driverPathList;
	}
	
}
