import java.util.ArrayList;


public class Passenger {
private String passengerLastName;
private String passengerFirstName;
private String passengerCategory;
private int passengerAge;
private String passengerPhoneNumber;
private String passengerAddress;
private String passengerMail;
private String passengerId; 
private String appreciation;
private String passengerJob;
private ArrayList<Path> rideHistory;
	
	//costructeurs
	public Passenger() 
	{
		this.passengerLastName = "";
		this.passengerFirstName = "";
		this.passengerCategory = "";
		this.passengerAge = 0;
		this.passengerPhoneNumber = "";
		this.passengerAddress = "";
		this.passengerMail = "";
		this.passengerId = "";
		this.appreciation = "";
		this.passengerJob = "";
		this.rideHistory = new ArrayList<Path>();
	}
	
	public Passenger(String lastName,String firstName,String category,int age,String phoneNumber,String address,String mail,String id,String appreciation,String profession) 
	{
		this.passengerLastName = lastName;
		this.passengerFirstName = firstName;
		this.passengerCategory = category;
		this.passengerAge = age;
		this.passengerPhoneNumber = phoneNumber;
		this.passengerAddress = address;
		this.passengerMail = mail;
		this.passengerId = id;
		this.appreciation = appreciation;
		this.passengerJob = profession;
		this.rideHistory = new ArrayList<Path>();
	}

	// Getters 
	public String getPassengerLastName() {
		return passengerLastName;
	}

	public String getPassengerFirstName() {
		return passengerFirstName;
	}

	public String getPassengerCategory() {
		return passengerCategory;
	}

	public int getPassengerAge() {
		return passengerAge;
	}

	public String getPassengerPhoneNumber() {
		return passengerPhoneNumber;
	}

	public String getPassengerAddress() {
		return passengerAddress;
	}

	public String getPassengerMail() {
		return passengerMail;
	}

	public String getPassengerId() {
		return passengerId;
	}

	public String getAppreciation() {
		return appreciation;
	}

	public String getPassengerJob() {
		return passengerJob;
	}

	public ArrayList<Path> getRideHistory() {
		return rideHistory;
	}

	// setter 
	public void setPassengerLastName(String passengerLastName) {
		this.passengerLastName = passengerLastName;
	}

	public void setPassengerFirstName(String passengerFirstName) {
		this.passengerFirstName = passengerFirstName;
	}

	public void setPassengerCategory(String passengerCategory) {
		this.passengerCategory = passengerCategory;
	}

	public void setPassengerAge(int passengerAge) {

			this.passengerAge = passengerAge;
	}

	public boolean setPassengerPhoneNumber(String passengerPhoneNumber) {
		
		boolean correct = false;
		if (this.passengerPhoneNumber.matches("0-9]{10}"))
		{
			this.passengerPhoneNumber = passengerPhoneNumber;
			correct = true;
		}
		return correct;
	}

	public boolean setPassengerAddress(String passengerAddress) {	
		boolean correct = false;
		if (this.passengerAddress.matches("[a-zA-Z0-9]"))
		{
			this.passengerAddress = passengerAddress;
			correct = true;
		}
		return correct;
	}

	public boolean setPassengerMail(String passengerMail) {
		boolean correct = false;
		if (this.passengerMail.matches("[a-zA-Z0-9]@[a-zA-Z].[a-zA-Z]{2.3}"))
		{
			this.passengerMail = passengerMail;
			correct = true;
		}
		return correct;
	}

	public void setPassengerId(String passengerId) {
		this.passengerId = passengerId;
	}

	public void setAppreciation(String appreciation) {
		this.appreciation = appreciation;
	}

	public void setPassengerJob(String passengerJob) {
		this.passengerJob = passengerJob;
	}

	public void setRideHistory(ArrayList<Path> rideHistory) {
		this.rideHistory = rideHistory;
	}
	
	//
	
	public double CalculatePrice()
	{
		// a faire
		return 0;
	}
	
	public void displayAllRide()
	{
		// a faire
	}
	
	public void displayLastRide()
	{
		// a faire
	}
}
