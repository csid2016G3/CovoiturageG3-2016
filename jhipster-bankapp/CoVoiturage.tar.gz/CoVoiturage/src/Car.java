import java.util.ArrayList;

public class Car {
	private boolean CarAllowSmoker;
	private boolean CarAllowAnimals;
	private boolean CarAllowBagages;
	private ArrayList<String> CarMusicType;
	private int CarNbPlace;
	private int CarNbBabyCarSeat;
	private String CarFuel;
	private String CarType;
	
	public Car(boolean carAllowSmoker, boolean carAllowAnimals, boolean carAllowBagages, ArrayList<String> carMusicType,
			int carNbPlace, int carNbBabyCarSeat, String carFuel, String carType) {
		super();
		CarAllowSmoker = carAllowSmoker;
		CarAllowAnimals = carAllowAnimals;
		CarAllowBagages = carAllowBagages;
		CarMusicType = carMusicType;
		CarNbPlace = carNbPlace;
		CarNbBabyCarSeat = carNbBabyCarSeat;
		CarFuel = carFuel;
		CarType = carType;
	}

	public Car() {
		// TODO Auto-generated constructor stub
	}

}
