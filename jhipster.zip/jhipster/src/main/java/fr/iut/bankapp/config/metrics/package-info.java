/**
 * Health and Metrics specific code.
 */
package fr.iut.bankapp.config.metrics;
