/**
 * Spring MVC REST controllers.
 */
package fr.iut.bankapp.web.rest;
