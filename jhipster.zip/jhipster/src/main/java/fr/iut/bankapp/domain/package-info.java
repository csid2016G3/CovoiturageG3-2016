/**
 * JPA domain objects.
 */
package fr.iut.bankapp.domain;
