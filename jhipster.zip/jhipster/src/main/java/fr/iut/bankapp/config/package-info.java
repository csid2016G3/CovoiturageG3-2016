/**
 * Spring Framework configuration files.
 */
package fr.iut.bankapp.config;
