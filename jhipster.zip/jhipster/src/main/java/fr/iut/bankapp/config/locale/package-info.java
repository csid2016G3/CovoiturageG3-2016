/**
 * Locale specific code.
 */
package fr.iut.bankapp.config.locale;
