/**
 * Service layer beans.
 */
package fr.iut.bankapp.service;
