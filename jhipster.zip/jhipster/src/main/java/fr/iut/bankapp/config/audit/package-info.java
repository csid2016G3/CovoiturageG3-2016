/**
 * Audit specific code.
 */
package fr.iut.bankapp.config.audit;
