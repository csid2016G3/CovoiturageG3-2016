/**
 * Data Transfer Objects used by Spring MVC REST controllers.
 */
package fr.iut.bankapp.web.rest.dto;
