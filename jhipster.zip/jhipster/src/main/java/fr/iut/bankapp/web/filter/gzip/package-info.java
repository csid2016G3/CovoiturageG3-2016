/**
 * GZipping servlet filter.
 */
package fr.iut.bankapp.web.filter.gzip;
