/**
 * Spring Security configuration.
 */
package fr.iut.bankapp.security;
