/**
 * Spring Data JPA repositories.
 */
package fr.iut.bankapp.repository;
