/**
 * Swagger api specific code.
 */
package fr.iut.bankapp.config.apidoc;